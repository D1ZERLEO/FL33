base_url = 'https://api.vk.com/method/'

get_dialogs = base_url + 'messages.getDialogs'
get_members = base_url + 'groups.getMembers'
get_user_info = base_url + 'users.get'
is_messages_allow = base_url + 'messages.isMessagesFromGroupAllowed'
send_message = base_url + 'messages.send'
upload_server_url = base_url + 'photos.getMessagesUploadServer'
save_photo_url = base_url + 'photos.saveMessagesPhoto'
